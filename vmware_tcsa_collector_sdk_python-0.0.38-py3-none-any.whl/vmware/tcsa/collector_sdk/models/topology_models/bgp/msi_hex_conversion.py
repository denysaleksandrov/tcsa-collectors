from vmware.tcsa.collector_sdk.models.topology import TCOTopology
import json


class MSI_HexConversion(TCOTopology):
    
    discoveryID: str
    timestamp: int
    name: str
    type: str
    domain: str
    Source: str
    jobID: str
    groupName: str
    action: str
    forceRefresh: bool
    collectorType: str
    initialized: bool
    ID: str
    value: float
    metrics: dict
    properties: dict
    relations: list

    @staticmethod
    def default_properties():
        return {
            "ServiceName" : None, 
            "CreationClassName" : None,            
}

    def __init__(self, discoveryID=None, timestamp=None, name=None, type="MSI_HexConversion", domain=None, Source=None, jobID=None, groupName=None, action=None, forceRefresh=False, collectorType=None, initialized=False, ID=None, value=0.0, metrics=None, properties=None, relations=None): 
        self.discoveryID = discoveryID
        self.timestamp = timestamp
        self.name = name
        self.type = "MSI_HexConversion"
        self.domain = domain
        self.Source = Source
        self.jobID = jobID
        self.groupName = groupName
        self.action = action
        self.forceRefresh = forceRefresh
        self.collectorType = collectorType
        self.initialized = initialized
        self.ID = ID
        self.value = value
        self.metrics = metrics
        properties_defaults = MSI_HexConversion.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        self.relations = relations

    @classmethod
    def from_dict(cls, d):
        discoveryID = d.get("discoveryID")
        timestamp = d.get("timestamp")
        name = d.get("name")
        type = d.get("type")
        domain = d.get("domain")
        Source = d.get("Source")
        jobID = d.get("jobID")
        groupName = d.get("groupName")
        action = d.get("action")
        forceRefresh = d.get("forceRefresh")
        collectorType = d.get("collectorType")
        initialized = d.get("initialized")
        ID = d.get("ID")
        value = d.get("value")
        metrics = d.get("metrics")
        properties = MSI_HexConversion.default_properties()
        properties_temp = d.get("properties")
        properties.update(properties_temp)
        relations = d.get("relations")
        return cls(discoveryID=discoveryID, timestamp=timestamp, name=name, type=type, domain=domain, Source=Source, jobID=jobID, groupName=groupName, action=action, forceRefresh=forceRefresh, collectorType=collectorType, initialized=initialized, ID=ID, value=value, metrics=metrics, properties=properties, relations=relations)

    def to_dict(self, remove_nones=False):
        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()

    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=indent, separators=separators)

