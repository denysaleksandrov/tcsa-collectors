from vmware.tcsa.collector_sdk.models.topology import TCOTopology
import json


class Card(TCOTopology):
    
    discoveryID: str
    timestamp: int
    name: str
    type: str
    domain: str
    Source: str
    jobID: str
    groupName: str
    action: str
    forceRefresh: bool
    collectorType: str
    initialized: bool
    ID: str
    value: float
    metrics: dict
    properties: dict
    relations: list

    @staticmethod
    def default_properties():
        return {
            "CIM_Name" : None, 
            "Status" : None, 
            "IsDownInRemote" : None, 
            "CIM_CreationClassName" : None, 
            "CreationClassName" : None, 
            "IsHavingProblems" : None, 
            "ManagedState" : None, 
            "Description" : None, 
            "StatusIsCriticalActive" : None, 
            "IsManaged" : None, 
            "SystemName" : None, 
            "indexVal" : None, 
            "Type" : None, 
            "Tag" : None, 
            "DisplayClassName" : None, 
            "Name" : None, 
            "ContainerIsHavingProblems" : None, 
            "unmanage_nr" : None, 
            "SuspendMe" : None, 
            "SerialNumber" : None, 
            "ServiceName" : None, 
            "KEYS" : None, 
            "DisplayName" : None, 
            "CIM_Description" : None, 
            "Reserved1" : None, 
            "Reserved2" : None, 
            "SystemIsManaged" : None, 
            "Location" : None, 
            "IsCardNotOperating" : None, 
            "OperationallyDown_attributes_From_Instr" : None, 
            "OperationalException" : None, 
            "ConnectivityException" : None, 
            "MonitoringEnabled" : None, 
            "RedundantUnitId" : None, 
            "IsParentPackageManaged" : None, 
            "IsSystemUnresponsive" : None, 
            "IsPackagedSystemManaged" : None, 
            "IsSwitchOverActive" : None, 
            "StandbyStatus" : None, 
            "InstrumentationClass" : None, 
            "PollingIndex" : None, 
            "ObjectKey" : None, 
            "IsProxyDown" : None, 
            "HasDownTrap" : None, 
            "unmanage" : None, 
            "IsProxy" : None, 
            "Reason" : None, 
            "IsUnresponsive" : None, 
            "manage" : None, 
            "Owner" : None, 
            "IsDown" : None, 
            "IsInternalShutdownDetected" : None, 
            "IsDegraded" : None, 
            "ComposedOfCausal" : None, 
            "IsLaserBiasDetected" : None, 
            "REPUNITMissing" : None, 
            "RemoteAlarmValue" : None, 
            "IsRxUnavailable" : None, 
            "IsTxUnavailable" : None, 
            "IsInternalLinkFailureDetected" : None, 
            "NativeEMSName" : None, 
            "DownOrUnavailable" : None, 
            "IsCardFailureDetected" : None, 
            "ResourceState" : None, 
            "IsDccFailureDetected" : None, 
            "TID" : None, 
            "IsCardRemovalDetected" : None, 
            "IsDcfOutFailDetected" : None, 
            "IsRelatedCardDown" : None, 
            "IsMismatch" : None, 
            "AlarmValue" : None, 
            "DownStatus" : None, 
            "IsAnyWorkingCardDown" : None, 
            "IsRxDown" : None, 
            "IsDcfLosDetected" : None, 
            "RemoteIsTrafficLost" : None, 
            "OtsLineFailed" : None, 
            "IsProtected" : None, 
            "IsLaserDown" : None, 
            "IsCardNotOperational" : None, 
            "IsSupervisoryLosDetected" : None, 
            "RemoteCcApriori" : None, 
            "HasSubCard" : None, 
            "IsTrafficLost" : None, 
            "ID" : None, 
            "IsServiceAffected" : None, 
            "RemoteIsXCDown" : None, 
            "TechnologyType" : None, 
            "RemoteIsProtected" : None, 
            "IsProtectionUnavailable" : None, 
            "IsUnavailable" : None, 
            "ObjectType" : None, 
            "UserLabel" : None, 
            "IsXCDown" : None, 
            "EqMISDetected" : None, 
            "IsCardConditionInappropriate" : None, 
            "IsTxDown" : None, 
            "RemoteIsServiceAffected" : None, 
            "RemoteDownOrUnavailable" : None, 
            "IsSwitchInhibited" : None, 
            "IsAtRisk" : None, 
            "IsCardUnavailable" : None, 
            "DWDMSide" : None, 
            "IsInternalReflectionDetected" : None, 
            "IsLaserTemperatureDetected" : None, 
            "IsProtectionDownOrInUse" : None, 
            "CardType" : None, 
            "IsCardMismatchDetected" : None, 
            "cc_apriori" : None, 
            "IsDcmFailureDetected" : None, 
            "IsForcedLaserShutdownDetected" : None, 
            "EQHWMISDetected" : None, 
            "RemoveComponents" : None, 
            "IsRouteReflector" : None, 
            "PrimaryOwnerContact" : None, 
            "ParentSystemIsManaged" : None, 
            "PrimaryOwnerName" : None, 
            "DeviceName" : None, 
            "DiscoveryAccessMethod" : None, 
            "getSystem" : None,            
}

    def __init__(self, discoveryID=None, timestamp=None, name=None, type="Card", domain=None, Source=None, jobID=None, groupName=None, action=None, forceRefresh=False, collectorType=None, initialized=False, ID=None, value=0.0, metrics=None, properties=None, relations=None): 
        self.discoveryID = discoveryID
        self.timestamp = timestamp
        self.name = name
        self.type = "Card"
        self.domain = domain
        self.Source = Source
        self.jobID = jobID
        self.groupName = groupName
        self.action = action
        self.forceRefresh = forceRefresh
        self.collectorType = collectorType
        self.initialized = initialized
        self.ID = ID
        self.value = value
        self.metrics = metrics
        properties_defaults = Card.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        self.relations = relations

    @classmethod
    def from_dict(cls, d):
        discoveryID = d.get("discoveryID")
        timestamp = d.get("timestamp")
        name = d.get("name")
        type = d.get("type")
        domain = d.get("domain")
        Source = d.get("Source")
        jobID = d.get("jobID")
        groupName = d.get("groupName")
        action = d.get("action")
        forceRefresh = d.get("forceRefresh")
        collectorType = d.get("collectorType")
        initialized = d.get("initialized")
        ID = d.get("ID")
        value = d.get("value")
        metrics = d.get("metrics")
        properties = Card.default_properties()
        properties_temp = d.get("properties")
        properties.update(properties_temp)
        relations = d.get("relations")
        return cls(discoveryID=discoveryID, timestamp=timestamp, name=name, type=type, domain=domain, Source=Source, jobID=jobID, groupName=groupName, action=action, forceRefresh=forceRefresh, collectorType=collectorType, initialized=initialized, ID=ID, value=value, metrics=metrics, properties=properties, relations=relations)

    def add_OutPort2(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OutPort2",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OutPort1(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OutPort1",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OcnInPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OcnInPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOfEquipment(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOfEquipment",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_CrossConnects(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "CrossConnects",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OcnOutPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OcnOutPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OchOutPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OchOutPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OutTransmissionPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OutTransmissionPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConcreteComponent_PartComponent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConcreteComponent_PartComponent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConcreteDependency_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConcreteDependency_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_MemberOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "MemberOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Container_PartComponent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Container_PartComponent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Realizes_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Realizes_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_HostsServices(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "HostsServices",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PeerPTP(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PeerPTP",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_RelatedTo(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "RelatedTo",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_CausedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "CausedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Causes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Causes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOfNE(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOfNE",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOfShelf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOfShelf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InstrumentedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InstrumentedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ComposedOfEquipment(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ComposedOfEquipment",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Impacts(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Impacts",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ProtectedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ProtectedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_HostedAccessPoint_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "HostedAccessPoint_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Aggregates(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Aggregates",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Underlying(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Underlying",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Notifications(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Notifications",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PackageTempMeasuredBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PackageTempMeasuredBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConfiguredBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConfiguredBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Realizes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Realizes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Protects(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Protects",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ComposedOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ComposedOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConnectedVia(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConnectedVia",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_SettingsAppliedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "SettingsAppliedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_HostedService_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "HostedService_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InTransmissionPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InTransmissionPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ReflectClients(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ReflectClients",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OchInPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OchInPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PackagesSystems(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PackagesSystems",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PackageCooledBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PackageCooledBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConnectsPhone(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConnectsPhone",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OwnedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OwnedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_SuspendMeRelation(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "SuspendMeRelation",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AggregatedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AggregatedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ImpactedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ImpactedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_LayeredOver(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "LayeredOver",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOfEquipmentProtectionGroup(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOfEquipmentProtectionGroup",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OutPort(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OutPort",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ComputerSystemPackage_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ComputerSystemPackage_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InPort2(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InPort2",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_HostsAccessPoints(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "HostsAccessPoints",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InPort1(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InPort1",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOfCard(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOfCard",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_StoresDataOn(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "StoresDataOn",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def to_dict(self, remove_nones=False):
        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()

    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=indent, separators=separators)

