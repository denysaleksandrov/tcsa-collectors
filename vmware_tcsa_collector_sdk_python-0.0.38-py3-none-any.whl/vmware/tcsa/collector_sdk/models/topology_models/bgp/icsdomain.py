from vmware.tcsa.collector_sdk.models.topology import TCOTopology
import json


class ICSDomain(TCOTopology):
    
    discoveryID: str
    timestamp: int
    name: str
    type: str
    domain: str
    Source: str
    jobID: str
    groupName: str
    action: str
    forceRefresh: bool
    collectorType: str
    initialized: bool
    ID: str
    value: float
    metrics: dict
    properties: dict
    relations: list

    @staticmethod
    def default_properties():
        return {
            "Name" : None, 
            "DomainName" : None, 
            "ServiceName" : None, 
            "State" : None, 
            "CreationClassName" : None, 
            "LastTopoSyncStartedAt" : None, 
            "DiscoveryInProgress" : None, 
            "Description" : None, 
            "LastTopoSyncEndedAt" : None, 
            "DisplayName" : None, 
            "SynchronizationCount" : None, 
            "Type" : None, 
            "LastHeartbeatTime" : None, 
            "DisplayClassName" : None, 
            "Is80OrLater" : None, 
            "LastConnectedAt" : None, 
            "detachTime" : None, 
            "attachTime" : None, 
            "Pattern" : None, 
            "Tag" : None,            
}

    def __init__(self, discoveryID=None, timestamp=None, name=None, type="ICSDomain", domain=None, Source=None, jobID=None, groupName=None, action=None, forceRefresh=False, collectorType=None, initialized=False, ID=None, value=0.0, metrics=None, properties=None, relations=None): 
        self.discoveryID = discoveryID
        self.timestamp = timestamp
        self.name = name
        self.type = "ICSDomain"
        self.domain = domain
        self.Source = Source
        self.jobID = jobID
        self.groupName = groupName
        self.action = action
        self.forceRefresh = forceRefresh
        self.collectorType = collectorType
        self.initialized = initialized
        self.ID = ID
        self.value = value
        self.metrics = metrics
        properties_defaults = ICSDomain.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        self.relations = relations

    @classmethod
    def from_dict(cls, d):
        discoveryID = d.get("discoveryID")
        timestamp = d.get("timestamp")
        name = d.get("name")
        type = d.get("type")
        domain = d.get("domain")
        Source = d.get("Source")
        jobID = d.get("jobID")
        groupName = d.get("groupName")
        action = d.get("action")
        forceRefresh = d.get("forceRefresh")
        collectorType = d.get("collectorType")
        initialized = d.get("initialized")
        ID = d.get("ID")
        value = d.get("value")
        metrics = d.get("metrics")
        properties = ICSDomain.default_properties()
        properties_temp = d.get("properties")
        properties.update(properties_temp)
        relations = d.get("relations")
        return cls(discoveryID=discoveryID, timestamp=timestamp, name=name, type=type, domain=domain, Source=Source, jobID=jobID, groupName=groupName, action=action, forceRefresh=forceRefresh, collectorType=collectorType, initialized=initialized, ID=ID, value=value, metrics=metrics, properties=properties, relations=relations)

    def add_ManagedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ManagedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_CausedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "CausedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Causes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Causes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AggregatedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AggregatedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ImpactedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ImpactedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_MetaConsistsOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "MetaConsistsOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_FinishedDiscovery(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "FinishedDiscovery",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Impacts(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Impacts",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Aggregates(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Aggregates",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InDiscovery(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InDiscovery",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_MemberOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "MemberOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConsistsOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConsistsOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_DiscoveredBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "DiscoveredBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Notifies(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Notifies",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def to_dict(self, remove_nones=False):
        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()

    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=indent, separators=separators)

