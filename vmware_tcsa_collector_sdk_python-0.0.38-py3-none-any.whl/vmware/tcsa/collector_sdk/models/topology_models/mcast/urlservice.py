from vmware.tcsa.collector_sdk.models.topology import TCOTopology
import json


class URLService(TCOTopology):
    
    discoveryID: str
    timestamp: int
    name: str
    type: str
    domain: str
    Source: str
    jobID: str
    groupName: str
    action: str
    forceRefresh: bool
    collectorType: str
    initialized: bool
    ID: str
    value: float
    metrics: dict
    properties: dict
    relations: list

    @staticmethod
    def default_properties():
        return {
            "ProcessName" : None, 
            "IsVMDown" : None, 
            "IsHighMemoryUtilizationActive" : None, 
            "SmoothingForHighMemoryUtilization" : None, 
            "CIM_CreationClassName" : None, 
            "UnderlyingAdapterIsHavingProblems" : None, 
            "IsVMPoweredOff" : None, 
            "IsHavingProblems" : None, 
            "ManagedState" : None, 
            "IsManaged" : None, 
            "SystemName" : None, 
            "indexVal" : None, 
            "NoHighMemoryUtilizationDelay" : None, 
            "MissingProcessesArguments" : None, 
            "TimeoutHighCPUUtilization" : None, 
            "HostedByHavingProblems" : None, 
            "HostSNMPAgentNotResponding" : None, 
            "Name" : None, 
            "AprioriProbability" : None, 
            "SystemObjectID" : None, 
            "SuspendMe" : None, 
            "ServiceName" : None, 
            "MemoryUtilization" : None, 
            "ProcessorUtilization" : None, 
            "CountThresholdsViolated" : None, 
            "PartOfHavingProblems" : None, 
            "ContainingSystemIsManaged" : None, 
            "IsCritical" : None, 
            "StatusIsDown" : None, 
            "Location" : None, 
            "IsMemoryUtilizationExceeded" : None, 
            "HighMemoryUtilizationActiveTime" : None, 
            "IsCountThresholdViolated" : None, 
            "SystemCreationClassName" : None, 
            "IsMissingProcess" : None, 
            "CIM_Name" : None, 
            "IsServiceAffected" : None, 
            "AccessedViaLogicalEndPoint" : None, 
            "IsHighCPUUtilizationActive" : None, 
            "SmoothingForHighCPUUtilization" : None, 
            "CreationClassName" : None, 
            "Description" : None, 
            "GenericType" : None, 
            "SystemVendor" : None, 
            "Type" : None, 
            "Model" : None, 
            "DisplayClassName" : None, 
            "ProcessorUtilizationThreshold" : None, 
            "DiscoveryMethod" : None, 
            "ServiceKey" : None, 
            "MissingProcesses" : None, 
            "NoHighCPUUtilizationDelay" : None, 
            "TimeoutHighMemoryUtilization" : None, 
            "IsHostUnresponsive" : None, 
            "IsCountThresholdViolatedNew" : None, 
            "unmanage_nr" : None, 
            "IsMissingCriticalProcess" : None, 
            "HypervisorHasHAerror" : None, 
            "HighCPUUtilizationActiveTime" : None, 
            "IsApplicationServiceGroupDown" : None, 
            "MemoryUtilizationThreshold" : None, 
            "ProcessArguments" : None, 
            "UnderlyingLogicalLinkIsHavingProblems" : None, 
            "KEYS" : None, 
            "DisplayName" : None, 
            "CIM_Description" : None, 
            "IsCPUUtilizationExceeded" : None, 
            "Vendor" : None, 
            "Reserved1" : None, 
            "Reserved2" : None, 
            "HostingSystemIsManaged" : None, 
            "ApplicationName" : None,            
}

    def __init__(self, discoveryID=None, timestamp=None, name=None, type="URLService", domain=None, Source=None, jobID=None, groupName=None, action=None, forceRefresh=False, collectorType=None, initialized=False, ID=None, value=0.0, metrics=None, properties=None, relations=None): 
        self.discoveryID = discoveryID
        self.timestamp = timestamp
        self.name = name
        self.type = "URLService"
        self.domain = domain
        self.Source = Source
        self.jobID = jobID
        self.groupName = groupName
        self.action = action
        self.forceRefresh = forceRefresh
        self.collectorType = collectorType
        self.initialized = initialized
        self.ID = ID
        self.value = value
        self.metrics = metrics
        properties_defaults = URLService.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        self.relations = relations

    @classmethod
    def from_dict(cls, d):
        discoveryID = d.get("discoveryID")
        timestamp = d.get("timestamp")
        name = d.get("name")
        type = d.get("type")
        domain = d.get("domain")
        Source = d.get("Source")
        jobID = d.get("jobID")
        groupName = d.get("groupName")
        action = d.get("action")
        forceRefresh = d.get("forceRefresh")
        collectorType = d.get("collectorType")
        initialized = d.get("initialized")
        ID = d.get("ID")
        value = d.get("value")
        metrics = d.get("metrics")
        properties = URLService.default_properties()
        properties_temp = d.get("properties")
        properties.update(properties_temp)
        relations = d.get("relations")
        return cls(discoveryID=discoveryID, timestamp=timestamp, name=name, type=type, domain=domain, Source=Source, jobID=jobID, groupName=groupName, action=action, forceRefresh=forceRefresh, collectorType=collectorType, initialized=initialized, ID=ID, value=value, metrics=metrics, properties=properties, relations=relations)

    def add_Initiates(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Initiates",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ServedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ServedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConfiguredBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConfiguredBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Serves(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Serves",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Uses(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Uses",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ComposedOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ComposedOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AccessedVia(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AccessedVia",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConnectedVia(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConnectedVia",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConcreteDependency_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConcreteDependency_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConcreteComponent_PartComponent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConcreteComponent_PartComponent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ServiceAccessBySAP_Dependent(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ServiceAccessBySAP_Dependent",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_SettingsAppliedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "SettingsAppliedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConnectedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConnectedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Consumes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Consumes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_MemberOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "MemberOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_vHostedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "vHostedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_OrchestratedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "OrchestratedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_PartOf(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "PartOf",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Executes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Executes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_CausedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "CausedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ManagesNetwork(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ManagesNetwork",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ProvidesConnectivityTo(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ProvidesConnectivityTo",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_SuspendMeRelation(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "SuspendMeRelation",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Causes(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Causes",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AdministratedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AdministratedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_HostedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "HostedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AggregatedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AggregatedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_LayeredOver(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "LayeredOver",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ImpactedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ImpactedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_InstrumentedBy(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "InstrumentedBy",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_RunningOn(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "RunningOn",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_AppliedTemplate(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "AppliedTemplate",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Impacts(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Impacts",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Aggregates(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Aggregates",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Underlying(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Underlying",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Produces(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Produces",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_ConnectedThrough(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "ConnectedThrough",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_Notifications(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "Notifications",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def add_StoresDataOn(self, topology: TCOTopology):
        relation_data = {"type": topology.type,
                "relationName": "StoresDataOn",
                "element": topology.name
        }
        if self.relations:
            self.relations.append(relation_data)
        else:
            self.relations = []
            self.relations.append(relation_data)

    def to_dict(self, remove_nones=False):
        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()

    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=indent, separators=separators)

