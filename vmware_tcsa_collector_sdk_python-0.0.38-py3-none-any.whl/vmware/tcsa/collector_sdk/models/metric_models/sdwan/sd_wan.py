import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class sd_wan(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "SDWAN"
        sub_domains = []
        metricType = "sd-wan"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = sd_wan.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = sd_wan.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = sd_wan.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "SDWAN"
        self.sub_domains = []
        self.metricType = "sd-wan"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = sd_wan.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = sd_wan.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = sd_wan.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "signalStrength": None,
         "bpsOfBestPathTx": None,
         "bestLossPctTx": None,
         "p1PacketsTx": None,
         "controlBytesRx": None,
         "bestLossPctRx": None,
         "p1PacketsRx": None,
         "bestJitterMsRx": None,
         "scoreRx": None,
         "p3BytesTx": None,
         "p2BytesRx": None,
         "controlBytesTx": None,
         "bestLatencyMsTx": None,
         "p3BytesRx": None,
         "p2PacketsRx": None,
         "bpsOfBestPathRx": None,
         "scoreTx": None,
         "p3PacketsTx": None,
         "bestLatencyMsRx": None,
         "p3PacketsRx": None,
         "p1BytesTx": None,
         "controlPacketsRx": None,
         "p2BytesTx": None,
         "p2PacketsTx": None,
         "bestJitterMsTx": None,
         "p1BytesRx": None,
         "controlPacketsTx": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "extractedName": None,
        }
    
    