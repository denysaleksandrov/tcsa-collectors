import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class rrc(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "5G"
        sub_domains = ['3GPP', 'vRAN']
        metricType = "RRC"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = rrc.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = rrc.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = rrc.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "5G"
        self.sub_domains = ['3GPP', 'vRAN']
        self.metricType = "RRC"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = rrc.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = rrc.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = rrc.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "RRC_ReEstabAtt_ReconfigurationFailure": None,
         "RRC_CASCellSetupAttempts": None,
         "RRC_CASCellSetupSuccess": None,
         "RRC_ConnEstabAtt_Emergency": None,
         "RRC_ConnEstabAtt_HighPriorityAccess": None,
         "RRC_ConnEstabAtt_MCSPriorityAccess": None,
         "RRC_ConnEstabAtt_MOData": None,
         "RRC_ConnEstabAtt_MOSignalling": None,
         "RRC_ConnEstabAtt_MOSMS": None,
         "RRC_ConnEstabAtt_MOVideoCall": None,
         "RRC_ConnEstabAtt_MOVoiceCall": None,
         "RRC_ConnEstabAtt_MPSPriorityAccess": None,
         "RRC_ConnEstabAtt_MTAccess": None,
         "RRC_ConnEstabSucc_Emergency": None,
         "RRC_ConnEstabSucc_HighPriorityAccess": None,
         "RRC_ConnEstabSucc_MCSPriorityAccess": None,
         "RRC_ConnEstabSucc_MOData": None,
         "RRC_ConnEstabSucc_MOSignalling": None,
         "RRC_ConnEstabSucc_MOSMS": None,
         "RRC_ConnEstabSucc_MOVideoCall": None,
         "RRC_ConnEstabSucc_MOVoiceCall": None,
         "RRC_ConnEstabSucc_MPSPriorityAccess": None,
         "RRC_ConnEstabSucc_MTAccess": None,
         "RRC_ConnEstabTime_Emergency": None,
         "RRC_ConnEstabTime_HighPriorityAccess": None,
         "RRC_ConnEstabTime_MCSPriorityAccess": None,
         "RRC_ConnEstabTime_MOData": None,
         "RRC_ConnEstabTime_MOSignalling": None,
         "RRC_ConnEstabTime_MOSMS": None,
         "RRC_ConnEstabTime_MOVideoCall": None,
         "RRC_ConnEstabTime_MOVoiceCall": None,
         "RRC_ConnEstabTime_MPSPriorityAccess": None,
         "RRC_ConnEstabTime_MTAccess": None,
         "RRC_currentNoOfActiveCellCA": None,
         "RRC_currentNoOfConfiguredCellCA": None,
         "RRC_currentNoOfRRCCxns": None,
         "RRC_currentNoOfRrcCxnsCA": None,
         "RRC_ReEstabAtt_HandoverFailure": None,
         "RRC_ReEstabAtt_OtherFailure": None,
         "RRC_ReEstabSuccWithUeContext_HandoverFailure": None,
         "RRC_ReEstabSuccWithUeContext_OtherFailure": None,
         "RRC_ReEstabSuccWithUeContext_ReconfigurationFailure": None,
         "RRCRsrpDistribution_UENbrRsrpDist": None,
         "RRCRsrqDistribution_UENbrRsrqDist": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "CUCPID": None,
         "RUID": None,
         "DUID": None,
         "CellClusterId": None,
         "kubernetes_namespace": None,
         "address": None,
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
        }
    
    