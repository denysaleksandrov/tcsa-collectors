import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class mm(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "5G"
        sub_domains = ['3GPP', 'vRAN']
        metricType = "MM"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = mm.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = mm.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = mm.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "5G"
        self.sub_domains = ['3GPP', 'vRAN']
        self.metricType = "MM"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = mm.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = mm.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = mm.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "HoRsrqDist_UENbrRsrqDist": None,
         "HoRsrpDist_UENbrRsrpDist": None,
         "MM_UEs_HoInSucc": None,
         "MM_HoResAlloInterSucc": None,
         "MM_HoResAlloInterReq": None,
         "MM_HoResAlloInterFailResourceNotAvailable": None,
         "MM_HoResAlloInterFailOthers": None,
         "MM_HoResAlloInterFailEncIntAlgoNotSupported": None,
         "MM_HoResAlloInterFailCellNotAvailable": None,
         "MM_HoPrepInterSucc": None,
         "MM_HoPrepInterReq": None,
         "MM_HoPrepInterFailResourceNotAvailable": None,
         "MM_HoPrepInterFailRelocPrepTimerExpiry": None,
         "MM_HoPrepInterFailOthers": None,
         "MM_HoPrepInterFailEncIntAlgoNotSupported": None,
         "MM_HoPrepInterFailCellNotAvailable": None,
         "MM_HoOutExe5gsToEpsSucc": None,
         "MM_HoOutExe5gsToEpsReq": None,
         "MM_HoOutExe5gsToEpsFallbackSucc": None,
         "MM_HoOutExe5gsToEpsFallbackReq": None,
         "MM_HoOutExe5gsToEpsFallbackFail": None,
         "MM_HoOutExe5gsToEpsFail": None,
         "MM_HoOut5gsToEpsPrepSucc": None,
         "MM_HoOut5gsToEpsPrepReq": None,
         "MM_HoOut5gsToEpsPrepFailTNGRELOCprepExpiry": None,
         "MM_HoOut5gsToEpsPrepFailRadioResNotAvailable": None,
         "MM_HoOut5gsToEpsPrepFailOthers": None,
         "MM_HoOut5gsToEpsFallbackPrepSucc": None,
         "MM_HoOut5gsToEpsFallbackPrepReq": None,
         "MM_HoOut5gsToEpsFallbackPrepFailTNGRELOCprepexpiry": None,
         "MM_HoOut5gsToEpsFallbackPrepFailRadioResNotAvailable": None,
         "MM_HoOut5gsToEpsFallbackPrepFailOthers": None,
         "MM_HoNRToLTETimeTotal": None,
         "MM_HoIntraNRIntraCUTotExeTime": None,
         "MM_HoIntraNRInterCUTotTime": None,
         "MM_HoIntraNRInterCUTotExeTime": None,
         "MM_HoExeIntraSucc": None,
         "MM_HoExeIntraReq": None,
         "MM_HoExeInterSucc": None,
         "MM_HoExeInterReq": None,
         "MM_HoExeInterFailRelocExpiry": None,
         "MM_HoExeInterFailOthers": None,
         "MM_HoExeHoNRToLTETimeTotal": None,
         "MM_HoExeHo5gsToEpsFallbackTimeTotal": None,
         "MM_Ho5gsToEpsFallbackTimeTotal": None,
         "MM_5QI_HoInAtt": None,
         "MM_5QI_HoInSucc": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "CUCPID": None,
         "RUID": None,
         "DUID": None,
         "CellClusterId": None,
         "kubernetes_namespace": None,
         "address": None,
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
        }
    
    