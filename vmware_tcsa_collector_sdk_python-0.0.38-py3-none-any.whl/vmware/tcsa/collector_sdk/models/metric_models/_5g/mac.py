import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class mac(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "5G"
        sub_domains = ['3GPP', 'vRAN']
        metricType = "MAC"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = mac.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = mac.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = mac.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "5G"
        self.sub_domains = ['3GPP', 'vRAN']
        self.metricType = "MAC"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = mac.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = mac.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = mac.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "MacHarqDl16qam": None,
         "MacHarqDl64qam": None,
         "MacHarqDl256qam": None,
         "MacHarqDlQpsk": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "CUCPID": None,
         "RUID": None,
         "DUID": None,
         "CellClusterId": None,
         "kubernetes_namespace": None,
         "address": None,
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
        }
    
    