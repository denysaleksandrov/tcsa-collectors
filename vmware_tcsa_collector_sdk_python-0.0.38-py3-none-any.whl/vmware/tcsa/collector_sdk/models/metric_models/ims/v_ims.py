import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class v_ims(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "IMS"
        sub_domains = ['VIMS']
        metricType = "vIMS"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = v_ims.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = v_ims.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = v_ims.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "IMS"
        self.sub_domains = ['VIMS']
        self.metricType = "vIMS"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = v_ims.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = v_ims.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = v_ims.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "SCSCFInitialRegistrationSuccesses": None,
         "SCSCFInitialRegistrationAttempts": None,
         "SCSCFInitialRegistrationFailures": None,
         "SCSCFInitialRegistrationSuccessPercent": None,
         "SCSCFVideoSessionSetupTimeAverage": None,
         "SCSCFVideoSessionSetupTimeVariance": None,
         "SCSCFVideoSessionSetupTimeHWM": None,
         "SCSCFVideoSessionSetupTimeLWM": None,
         "SCSCFVideoSessionSetupTimeCount": None,
         "SCSCFAudioSessionSetupTimeAverage": None,
         "SCSCFAudioSessionSetupTimeVariance": None,
         "SCSCFAudioSessionSetupTimeHWM": None,
         "SCSCFAudioSessionSetupTimeLWM": None,
         "SCSCFAudioSessionSetupTimeCount": None,
         "ICSCFSessionEstablishmentSuccesses": None,
         "ICSCFSessionEstablishmentFailures": None,
         "ICSCFSessionEstablishmentAttempts": None,
         "ICSCFSessionEstablishmentSuccessPercent": None,
         "ICSCFSessionEstablishmentNetworkSuccesses": None,
         "ICSCFSessionEstablishmentNetworkFailures": None,
         "ICSCFSessionEstablishmentNetworkAttempts": None,
         "ICSCFSessionEstablishmentNetworkSuccessPercent": None,
         "QueueSuccessFailSuccesses": None,
         "QueueSuccessFailFailures": None,
         "QueueSuccessFailSuccessPercent": None,
         "QueueSuccessFailAttempts": None,
         "LatencyAverage": None,
         "LatencyVariance": None,
         "LatencyHWM": None,
         "LatencyLWM": None,
         "LatencyCount": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
         "ip": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
        }
    
    