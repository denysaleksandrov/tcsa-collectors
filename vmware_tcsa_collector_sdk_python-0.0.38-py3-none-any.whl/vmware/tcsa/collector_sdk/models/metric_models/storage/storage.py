import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class storage(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "Storage"
        sub_domains = ['IP', 'Virtual']
        metricType = "Storage"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = storage.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = storage.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = storage.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "Storage"
        self.sub_domains = ['IP', 'Virtual']
        self.metricType = "Storage"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = storage.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = storage.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = storage.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "Latency": None,
         "QueueLatency": None,
         "ReadLatency": None,
         "ReadThroughput": None,
         "WriteRequests": None,
         "ReadRequests": None,
         "PresentedCapacity": None,
         "WriteLatency": None,
         "WriteThroughput": None,
         "FreeCapacity": None,
         "Uncommitted": None,
         "Throughput": None,
         "Availability": None,
         "Capacity": None,
         "UsedCapacity": None,
         "TotalDisk": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
        }
    
    