import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class network_adapter(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    type: str
    timestamp: int
    instance: str
    processedTimestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "Network"
        sub_domains = ['NetworkAdapter']
        metricType = "NetworkAdapter"
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        metrics = network_adapter.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = network_adapter.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = network_adapter.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, type, timestamp, instance, processedTimestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, type=None, timestamp=None, instance=None, processedTimestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "Network"
        self.sub_domains = ['NetworkAdapter']
        self.metricType = "NetworkAdapter"
        self.type = type
        self.timestamp = timestamp
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        metrics_defaults = network_adapter.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = network_adapter.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = network_adapter.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "ifInUnknownProtos": None,
         "ifOperStatus": None,
         "ifInBroadcastPkts": None,
         "ifInMulticastPkts": None,
         "ifOutBroadcastPkts": None,
         "ifOutMulticastPkts": None,
         "ifOutDiscards": None,
         "ifHighSpeed": None,
         "ifHCOutOctets": None,
         "ifHCInOctets": None,
         "ifInDiscards": None,
         "ifOutOctets": None,
         "ifOutOctetsRate": None,
         "ifOutUcastPkts": None,
         "ifHCOutMulticastPkts": None,
         "ifHCOutBroadcastPkts": None,
         "ifHCInMulticastPkts": None,
         "ifHCInBroadcastPkts": None,
         "ifInOctets": None,
         "ifInOctetsRate": None,
         "ifOutErrors": None,
         "ifInUcastPkts": None,
         "ifHCOutUcastPkts": None,
         "ifHCInUcastPkts": None,
         "ifInErrors": None,
         "ifAdminStatus": None,
         "IOWrite": None,
         "IORead": None,
         "ReadLatency": None,
         "ReadThroughput": None,
         "WriteLatency": None,
         "WriteThroughput": None,
         "Throughput": None,
         "Availability": None,
         "CurrentUtilization": None,
         "Received": None,
         "Transmitted": None,
         "InputPacketErrorPct": None,
         "IsConnectedVMPoweredDown": None,
         "IsDisabled": None,
         "OutputPacketErrorPct": None,
         "ReceivedErrorsCount": None,
         "ReceivedPacketsCount": None,
         "ReceivedPacketsErrorRate": None,
         "ReceivedPacketsRate": None,
         "TransmittedErrorsCount": None,
         "TransmittedPacketsCount": None,
         "TransmittedPacketsErrorRate": None,
         "TransmittedPacketsRate": None,
         "UpStatus": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
         "ip": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "hostname": None,
         "hypervsr": None,
         "ifSpeed": None,
        }
    
    