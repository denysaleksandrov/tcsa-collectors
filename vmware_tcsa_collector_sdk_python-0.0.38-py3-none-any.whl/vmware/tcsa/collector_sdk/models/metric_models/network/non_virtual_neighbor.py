import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class non_virtual_neighbor(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    instance: str
    processedTimestamp: int
    type: str
    timestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "Network"
        sub_domains = ['NonVirtualNeighbor']
        metricType = "NonVirtualNeighbor"
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        metrics = non_virtual_neighbor.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = non_virtual_neighbor.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = non_virtual_neighbor.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, instance, processedTimestamp, type, timestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, instance=None, processedTimestamp=None, type=None, timestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "Network"
        self.sub_domains = ['NonVirtualNeighbor']
        self.metricType = "NonVirtualNeighbor"
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        self.type = type
        self.timestamp = timestamp
        metrics_defaults = non_virtual_neighbor.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = non_virtual_neighbor.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = non_virtual_neighbor.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "ospfNbrState": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
         "ip": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
        }
    
    