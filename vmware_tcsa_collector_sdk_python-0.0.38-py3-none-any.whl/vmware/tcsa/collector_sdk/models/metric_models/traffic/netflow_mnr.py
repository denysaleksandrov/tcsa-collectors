import json
import time
from vmware.tcsa.collector_sdk.models.metric import TCOMetric


class netflow_mnr(TCOMetric):
    
    domain: str
    sub_domains: str
    metricType: str
    instance: str
    processedTimestamp: int
    type: str
    timestamp: int
    metrics: dict
    properties: dict
    tags: dict
    
    def __init__(self):
        pass
    
    @classmethod
    def from_dict(cls, d):
        domain = "Traffic"
        sub_domains = ['Netflow']
        metricType = "Netflow-mnr"
        instance = d.get("instance", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        type = d.get("type", None)
        timestamp = d.get("timestamp", None)
        metrics = netflow_mnr.default_metrics()
        metrics_temp = d.get("metrics", {})
        metrics.update(metrics_temp)
        properties = netflow_mnr.default_properties()
        properties_temp = d.get("properties", {})
        properties.update(properties_temp)
        tags = netflow_mnr.default_tags()
        tags_temp = d.get("tags", {})
        tags.update(tags_temp)
        return cls(domain, sub_domains, metricType, instance, processedTimestamp, type, timestamp, metrics, properties, tags)
    
    def __init__(self, domain=None, sub_domains=None, metricType=None, instance=None, processedTimestamp=None, type=None, timestamp=None, metrics=None, properties=None, tags=None):
        self.domain = "Traffic"
        self.sub_domains = ['Netflow']
        self.metricType = "Netflow-mnr"
        self.instance = instance
        self.processedTimestamp = processedTimestamp if processedTimestamp is  not None else int(time.time()*1000)
        self.type = type
        self.timestamp = timestamp
        metrics_defaults = netflow_mnr.default_metrics()
        metrics_defaults.update(metrics)
        self.metrics = metrics_defaults
        properties_defaults = netflow_mnr.default_properties()
        properties_defaults.update(properties)
        self.properties = properties_defaults
        tags_defaults = netflow_mnr.default_tags()
        tags_defaults.update(tags)
        self.tags = tags_defaults
    
    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True, indent=indent, separators=separators)
    
    @staticmethod
    def default_metrics():
        return {
         "FLOW_COUNT": None,
         "PACKETSOUT": None,
         "MINUS_Y": None,
         "MINUS_X": None,
         "MINUS_Z": None,
         "PACKETSIN": None,
         "AZ_PACKETS": None,
         "BYTESIN": None,
         "BYTESOUT": None,
         "ZA_PACKETS": None,
         "ZA_BYTES": None,
         "BYTES": None,
         "AZ_BYTES": None,
         "PACKETS": None,
        }
    
    @staticmethod
    def default_properties():
        return {
         "entityName": None,
         "dataSource": None,
         "deviceName": None,
         "entityType": None,
         "deviceType": None,
         "SNMP_NAME": None,
         "eventTmst": None,
         "source": None,
         "REMOTE_PORT": None,
         "INTERFACE": None,
         "unitFLOW_COUNT": None,
         "TCP_FLAGS": None,
         "DSCP": None,
         "APPLICATION_NAME": None,
         "HOST_PORT": None,
         "Z_IF_SNMP": None,
         "eventId": None,
         "PORT": None,
         "PROTOCOL": None,
         "ROUTER_SRC": None,
         "Z_PORT": None,
         "L4_DST_PORT": None,
         "TOS": None,
         "TOS_REST": None,
         "HOST_ADDR": None,
         "APPLICATION_TYPE": None,
         "APPLICATION_ID": None,
         "A_IF_SNMP_NAME": None,
         "A_IF_SNMP": None,
         "DST_AS": None,
         "OUTPUT_SNMP": None,
         "APPLICATION_CRITICALITY": None,
         "ROUTER_SRC_NAME": None,
         "HOST_NAME": None,
         "Z_ADDR": None,
         "INPUT_SNMP_NAME": None,
         "INPUT_SNMP": None,
         "SRC_ADDR": None,
         "APPLICATION_DESC": None,
         "OUTPUT_SNMP_NAME": None,
         "DIRECTION": None,
         "STREAM": None,
         "A_ADDR": None,
         "DST_MASK": None,
         "DST_ADDR": None,
         "IPV4_DST_ADDR": None,
         "IPV4_DST_NET": None,
         "IPV4_NEXT_HOP": None,
         "A_PORT": None,
         "SRC_MASK": None,
         "SOURCE_ID": None,
         "DST_PORT": None,
         "FLOW_SEQUENCE": None,
         "Z_IF_SNMP_NAME": None,
         "IPV4_SRC_NET": None,
         "DURATION": None,
         "LAST_SWITCHED": None,
         "FIRST_SWITCHED": None,
        }
    
    @staticmethod
    def default_tags():
        return {
         "address": None,
         "region": None,
         "deviceCoordinates": None,
         "version": None,
         "location": None,
         "zip": None,
         "model": None,
         "city": None,
         "customer": None,
        }
    
    