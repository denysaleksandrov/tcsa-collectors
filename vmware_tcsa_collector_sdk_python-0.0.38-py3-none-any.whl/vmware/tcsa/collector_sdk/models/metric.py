import time
from vmware.tcsa.collector_sdk.models.base import TCOBase
import json


class TCOMetric(TCOBase):
    instance: str
    metricType: str
    timestamp: int
    processedTimestamp: int
    type: str
    metrics: dict
    properties: dict
    tags: dict

    @classmethod
    def from_dict(cls, d):
        instance = d.get("instance", None)
        metricType = d.get("metricType", None)
        timestamp = d.get("timestamp", None)
        processedTimestamp = d.get("processedTimestamp", int(time.time()*1000))
        type = d.get("type", None)
        metrics = d.get("metrics", {})
        properties = d.get("properties", {})
        tags = d.get("tags", {})
        return cls(instance, metricType, timestamp, processedTimestamp, type, metrics, properties, tags)

    def __init__(self, instance, metricType, timestamp, processedTimestamp, type, metrics, properties, tags):
        self.instance = instance
        self.metricType = metricType
        self.timestamp = timestamp
        self.processedTimestamp = processedTimestamp
        self.type = type
        self.metrics = metrics
        self.properties = properties
        self.tags = tags

    def toJSON(self, separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=indent, separators=separators)

    def to_dict(self, remove_nones=False):
        """
        Creates a dictionary representation of the object.
        :param remove_nones: Whether ``None`` values should be filtered out of the dictionary.  Defaults to ``False``.
        :return: The dictionary representation.
        """

        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()
