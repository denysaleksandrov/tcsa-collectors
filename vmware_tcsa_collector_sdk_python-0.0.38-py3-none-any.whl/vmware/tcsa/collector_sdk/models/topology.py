import json
from vmware.tcsa.collector_sdk.models.base import TCOBase


class TCOTopology(TCOBase):
    type: str
    Source: str
    forceRefresh: bool
    collectorType: str
    discoveryID: str
    jobID: str
    domain: str
    jobId: str
    groupName: str
    name: str
    action: str
    initialized: bool
    ID: str
    value: float
    timestamp: int
    properties: {}
    relations: []
    metrics: {}

    @classmethod
    def from_dict(cls, d):
        type = d.get("type", None)
        Source = d.get("Source", None)
        forceRefresh = d.get("forceRefresh", None)
        collectorType = d.get("collectorType", None)
        discoveryID = d.get("discoveryID", None)
        jobID = d.get("jobID", None)
        groupName = d.get("groupName", None)
        name = d.get("name", None)
        action = d.get("action", None)
        initialized = d.get("initialized", False)
        ID = d.get("ID", None)
        value = d.get("value", 0.0)
        timestamp = d.get("timestamp", None)
        properties = d.get("properties", {})
        relations = d.get("relations", [])
        metrics = d.get("metrics", {})
        domain = d.get("domain")

        return cls(type=type, Source=Source, forceRefresh=forceRefresh, collectorType=collectorType, discoveryID=discoveryID, jobID=jobID,
                   groupName=groupName, name=name, action=action, initialized=initialized, ID=ID, value=value, timestamp=timestamp,
                   properties=properties, relations=relations, metrics=metrics, domain=domain)

    def __init__(self, type=None, Source=None, forceRefresh=None, collectorType=None, discoveryID=None, jobID=None,
                 groupName=None, name=None, action=None, initialized=None, ID=None, value=0.0, timestamp=None,
                 properties=None, relations=None, metrics=None, domain=None):
        self.type = type
        self.Source = Source
        self.forceRefresh = forceRefresh
        self.collectorType = collectorType
        self.discoveryID = discoveryID
        self.jobID = jobID
        self.groupName = groupName
        self.name = name
        self.action = action
        self.initialized = initialized
        self.ID = ID
        self.value = value
        self.timestamp = timestamp
        self.properties = properties
        self.relations = relations
        self.metrics = metrics
        self.domain = domain

    def toJSON(self,separators=None, indent=None):
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=indent, separators=separators)

    def to_dict(self, remove_nones=False):
        """
        Creates a dictionary representation of the object.
        :param remove_nones: Whether ``None`` values should be filtered out of the dictionary.  Defaults to ``False``.
        :return: The dictionary representation.
        """

        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()

