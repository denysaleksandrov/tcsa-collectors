from dataclasses import dataclass
from typing import List, Optional

@dataclass
class PluginRunTimeOption(object):
    main: str
    tests: Optional[List[str]]


@dataclass
class DependencyModule:
    name: str
    version: str

    def __str__(self) -> str:
        return f'{self.name}=={self.version}'


@dataclass
class PluginConfig:
    name: str
    alias: str
    creator: str
    runtime: PluginRunTimeOption
    repository: str
    description: str
    version: str
    requirements: Optional[List[DependencyModule]]
    collector_config: Optional[object]


@dataclass
class PackageMetaData:
    name: str
    description: str
    version: str
    configuration: dict

    def __str__(self) -> str:
        return f'{self.name}: {self.version}'
