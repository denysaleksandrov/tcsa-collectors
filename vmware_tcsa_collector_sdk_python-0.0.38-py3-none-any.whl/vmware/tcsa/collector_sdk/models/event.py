from vmware.tcsa.collector_sdk.models.base import TCOBase
import json
import time


class TCOEvent(TCOBase):
    @classmethod
    def from_dict(cls, d):
        pass

    Source: str
    Name: str
    InstanceName: str
    State: str
    Severity: str
    ProcessedTimeStamp: int
    Timestamp: int
    DisplayName: str
    EventDisplayName: str
    ClassName: str
    ClassDisplayName: str
    InstanceDisplayName: str
    ElementClassName: str
    ElementName: str
    EventName: str
    EventState: str
    EventText: str
    EventType: str
    Acknowledged: str
    Active: str
    Category: str
    Certainty: str
    ClearOnAcknowledge: str
    Impact: str
    InMaintenance: str
    IsProblem: str
    IsRoot: str
    PollingID: int
    PollingState: str
    SourceDomainName: str
    SourceEventType: str
    SourceInfo: str
    SourceSpecific: str
    TroubleTicketID: str
    Owner: str
    ToolInfo: str
    OccurrenceCount: str
    FirstNotifiedAt: int
    LastChangedAt: int
    LastNotifiedAt: int
    LastClearedAt: int
    AcknowledgmentTime: int
    UserDefined1: str
    UserDefined2: str
    UserDefined3: str
    UserDefined4: str
    UserDefined5: str
    UserDefined6: str
    UserDefined7: str
    UserDefined8: str
    UserDefined9: str
    UserDefined10: str
    UserDefined11: str
    UserDefined12: str
    UserDefined13: str
    UserDefined14: str
    UserDefined15: str
    UserDefined16: str
    UserDefined17: str
    UserDefined18: str
    UserDefined19: str
    UserDefined20: str
    tags: dict
    properties: dict

    def __init__(self, Source=None, Name=None, InstanceName=None, State=None, Severity=None, ProcessedTimeStamp=None,
                 Timestamp=None, DisplayName=None,
                 EventDisplayName=None, ClassName=None, ClassDisplayName=None, InstanceDisplayName=None,
                 ElementClassName=None, ElementName=None,
                 EventName=None, EventState=None, EventText=None, EventType=None, Acknowledged=None, Active=None,
                 Category=None, Certainty=None,
                 ClearOnAcknowledge=None, Impact=None, InMaintenance=None, IsProblem=None, IsRoot=None, PollingID=None,
                 PollingState=None,
                 SourceDomainName=None, SourceEventType=None, SourceInfo=None, SourceSpecific=None,
                 TroubleTicketID=None, Owner=None, ToolInfo=None,
                 OccurrenceCount=None, FirstNotifiedAt=None, LastChangedAt=None, LastNotifiedAt=None,
                 LastClearedAt=None, AcknowledgmentTime=None,
                 UserDefined1=None, UserDefined2=None, UserDefined3=None,
                 UserDefined4=None, UserDefined5=None, UserDefined6=None, UserDefined7=None, UserDefined8=None,
                 UserDefined9=None, UserDefined10=None, UserDefined11=None, UserDefined12=None, UserDefined13=None,
                 UserDefined14=None, UserDefined15=None, UserDefined16=None, UserDefined17=None, UserDefined18=None,
                 UserDefined19=None, UserDefined20 =None,
                 tags=None, properties=None):
        self.Source = Source
        self.Name = Name
        self.InstanceName = InstanceName
        self.State = State
        self.Severity = Severity
        self.ProcessedTimeStamp = ProcessedTimeStamp
        self.Timestamp = Timestamp
        self.DisplayName = DisplayName
        self.EventDisplayName = EventDisplayName
        self.ClassName = ClassName
        self.ClassDisplayName = ClassDisplayName
        self.InstanceDisplayName = InstanceDisplayName
        self.ElementClassName = ElementClassName
        self.ElementName = ElementName
        self.EventName = EventName
        self.EventState = EventState
        self.EventText = EventText
        self.EventType = EventType
        self.Acknowledged = Acknowledged
        self.Active = Active
        self.Category = Category
        self.Certainty = Certainty
        self.ClearOnAcknowledge = ClearOnAcknowledge
        self.Impact = Impact
        self.InMaintenance = InMaintenance
        self.IsProblem = IsProblem
        self.IsRoot = IsRoot
        self.PollingID = PollingID
        self.PollingState = PollingState
        self.SourceDomainName = SourceDomainName
        self.SourceEventType = SourceEventType
        self.SourceInfo = SourceInfo
        self.SourceSpecific = SourceSpecific
        self.TroubleTicketID = TroubleTicketID
        self.Owner = Owner
        self.ToolInfo = ToolInfo
        self.OccurrenceCount = OccurrenceCount
        self.FirstNotifiedAt = FirstNotifiedAt
        self.LastChangedAt = LastChangedAt
        self.LastNotifiedAt = LastNotifiedAt
        self.LastClearedAt = LastClearedAt
        self.AcknowledgmentTime = AcknowledgmentTime
        self.UserDefined1 = UserDefined1
        self.UserDefined2 = UserDefined2
        self.UserDefined3 = UserDefined3
        self.UserDefined4 = UserDefined4
        self.UserDefined5 = UserDefined5
        self.UserDefined6 = UserDefined6
        self.UserDefined7 = UserDefined7
        self.UserDefined8 = UserDefined8
        self.UserDefined9 = UserDefined9
        self.UserDefined10 = UserDefined10
        self.UserDefined11 = UserDefined11
        self.UserDefined12 = UserDefined12
        self.UserDefined13 = UserDefined13
        self.UserDefined14 = UserDefined14
        self.UserDefined15 = UserDefined15
        self.UserDefined16 = UserDefined16
        self.UserDefined17 = UserDefined17
        self.UserDefined18 = UserDefined18
        self.UserDefined19 = UserDefined19
        self.UserDefined20 = UserDefined20
        self.tags = tags
        self.properties = properties

    @classmethod
    def from_dict(cls, d):
        Source = d.get("Source", None)
        Name = d.get("Name", None)
        InstanceName = d.get("InstanceName", None)
        State = d.get("State", None)
        Severity = d.get("Severity", None)
        ProcessedTimeStamp = d.get("ProcessedTimeStamp", int(time.time()*1000))
        Timestamp = d.get("Timestamp", None)
        DisplayName = d.get("DisplayName", None)
        EventDisplayName = d.get("EventDisplayName", None)
        ClassName = d.get("ClassName", None)
        ClassDisplayName = d.get("ClassDisplayName", None)
        InstanceDisplayName = d.get("InstanceDisplayName", None)
        ElementClassName = d.get("ElementClassName", None)
        ElementName = d.get("ElementName", None)
        EventName = d.get("EventName", None)
        EventState = d.get("EventState", None)
        EventText = d.get("EventText", None)
        EventType = d.get("EventType", None)
        Acknowledged = d.get("Acknowledged", None)
        Active = d.get("Active", None)
        Category = d.get("Category", None)
        Certainty = d.get("Certainty", None)
        ClearOnAcknowledge = d.get("ClearOnAcknowledge", None)
        Impact = d.get("Impact", None)
        InMaintenance = d.get("InMaintenance", None)
        IsProblem = d.get("IsProblem", None)
        IsRoot = d.get("IsRoot", None)
        PollingID = d.get("PollingID", None)
        PollingState = d.get("PollingState", None)
        SourceDomainName = d.get("SourceDomainName", None)
        SourceEventType = d.get("SourceEventType", None)
        SourceInfo = d.get("SourceInfo", None)
        SourceSpecific = d.get("SourceSpecific", None)
        TroubleTicketID = d.get("TroubleTicketID", None)
        Owner = d.get("Owner", None)
        ToolInfo = d.get("ToolInfo", None)
        OccurrenceCount = d.get("OccurrenceCount", None)
        FirstNotifiedAt = d.get("FirstNotifiedAt", None)
        LastChangedAt = d.get("LastChangedAt", None)
        LastNotifiedAt = d.get("LastNotifiedAt", None)
        LastClearedAt = d.get("LastClearedAt", None)
        AcknowledgmentTime = d.get("AcknowledgmentTime", None)
        UserDefined1 = d.get("UserDefined1", None)
        UserDefined2 = d.get("UserDefined2", None)
        UserDefined3 = d.get("UserDefined3", None)
        UserDefined4 = d.get("UserDefined4", None)
        UserDefined5 = d.get("UserDefined5", None)
        UserDefined6 = d.get("UserDefined6", None)
        UserDefined7 = d.get("UserDefined7", None)
        UserDefined8 = d.get("UserDefined8", None)
        UserDefined9 = d.get("UserDefined9", None)
        UserDefined10 = d.get("UserDefined10", None)
        UserDefined11 = d.get("UserDefined11", None)
        UserDefined12 = d.get("UserDefined12", None)
        UserDefined13 = d.get("UserDefined13", None)
        UserDefined14 = d.get("UserDefined14", None)
        UserDefined15 = d.get("UserDefined15", None)
        UserDefined16 = d.get("UserDefined16", None)
        UserDefined17 = d.get("UserDefined17", None)
        UserDefined18 = d.get("UserDefined18", None)
        UserDefined19 = d.get("UserDefined19", None)
        UserDefined20 = d.get("UserDefined20", None)
        
        tags = d.get("tags", {})
        properties = d.get("properties", {})
        return cls(Source, Name, InstanceName, State, Severity, ProcessedTimeStamp, Timestamp, DisplayName,
                   EventDisplayName, ClassName, ClassDisplayName, InstanceDisplayName, ElementClassName, ElementName,
                   EventName, EventState, EventText, EventType, Acknowledged, Active, Category, Certainty,
                   ClearOnAcknowledge, Impact, InMaintenance, IsProblem, IsRoot, PollingID, PollingState,
                   SourceDomainName, SourceEventType, SourceInfo, SourceSpecific, TroubleTicketID, Owner, ToolInfo,
                   OccurrenceCount, FirstNotifiedAt, LastChangedAt, LastNotifiedAt, LastClearedAt, AcknowledgmentTime,
                   UserDefined1, UserDefined2, UserDefined3, UserDefined4, UserDefined5, UserDefined6, UserDefined7,
                   UserDefined8, UserDefined9, UserDefined10, UserDefined11, UserDefined12, UserDefined13,
                   UserDefined14, UserDefined15, UserDefined16, UserDefined17, UserDefined18, UserDefined19,
                   UserDefined20, tags, properties)

    def toJSON(self,separators=None, indent=None):
        self.EventState = self.State
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=indent, separators=separators)

    def to_dict(self, remove_nones=False):
        """
        Creates a dictionary representation of the object.
        :param remove_nones: Whether ``None`` values should be filtered out of the dictionary.  Defaults to ``False``.
        :return: The dictionary representation.
        """

        if remove_nones:
            return {k: v for k, v in self.to_dict().items() if v is not None}
        else:
            raise NotImplementedError()
