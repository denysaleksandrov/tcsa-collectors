import abc
import base64
import os
import ssl
from vmware.tcsa.collector_sdk.engine import PluginCore
from vmware.tcsa.collector_sdk.error.error import InputError
from confluent_kafka import Producer
import json
import tempfile
import atexit


def get_default_edge_kafka_conf():
    bootstrap_server = os.getenv("KAFKA_CONNECT", "kafka-edge:32092")
    username = os.getenv("KAFKA_USERNAME")
    password = os.getenv("KAFKA_PASSWORD")
    decode_password = base64.decodebytes(bytes(password, 'utf-8'))
    certificate = os.getenv("KAFKA_CERT")
    cert_pass = os.getenv("KAFKA_CERT_PASSWORD")
    certificate_passwd = base64.decodebytes(bytes(cert_pass, 'utf-8'))
    # Kafka SSL context with trusted CA certificates
    # Kafka configuration parameters
    kafka_config = {
        "bootstrap.servers": bootstrap_server,
        "security.protocol": "sasl_ssl",
        "sasl.mechanism": "SCRAM-SHA-512",
        "sasl.username": username,
        "sasl.password": decode_password.decode(),
        "ssl.ca.location": "/app/config/ca.pem"
    }
    return kafka_config


class BaseCollector(PluginCore):

    def __init__(self, logger, collector_configuration) -> None:
        self._collector_configuration = collector_configuration
        self.is_test = collector_configuration.is_test_run
        self.input_file = collector_configuration.collector_input_file
        self.output_file = collector_configuration.collector_output_file
        self.producer = None
        self.topic = None
        self._transformed_data = None
        self._collected_data = None
        atexit.register(self.flush_producer)
        super().__init__(logger)

    def get_producer(self):
        if self.producer is None:
            if self.is_test:
                return None
            bootstrap_server = None
            topic = self.get_destination_topic_name()
            is_remote = os.getenv("IS_REMOTE", False)
            if is_remote:
                config = self.get_remote_sink_config()
            else:
                if hasattr(self._collector_configuration, 'sink'):
                    if hasattr(self._collector_configuration.sink, 'properties') and hasattr(
                            self._collector_configuration.sink.properties, 'bootstrap_servers'):
                        bootstrap_server = self._collector_configuration.sink.properties.bootstrap_servers

                if bootstrap_server is None or bootstrap_server == '':
                    bootstrap_server = os.getenv("KAFKA_CONNECT", 'internal-kafka-bootstrap:9092')

                if bootstrap_server is None or topic is None:
                    self._logger.error("sink topic and bootstrap servers cannot be empty")
                    raise InputError("sink topic and bootstrap servers cannot be empty")
                config = {"bootstrap.servers": bootstrap_server,
                          "batch.size": 32768,  # Adjust the batch size as per your requirements
                          "linger.ms": 10}
                # TODO add auth config
                auth_config = self.__add_producer_auth_config()
                config.update(auth_config)
            self.producer = Producer(config)
            self.topic = topic

        return self.producer, self.topic

    @abc.abstractmethod
    def invoke(self, command: chr):
        pass

    def publish(self, publish_data, collector_type='metric'):
        """
        this method is used to publish the transformed data into internal kafka bus.
        :param collector_type:
        :param publish_data:
        :return:
        """
        self._logger.debug("start publish ")
        if self.is_test:
            self._logger.info("--test flag enabled , publish to output file {file} ".format(file=self.output_file))
            with open(self.output_file, 'a') as fpo:
                fpo.write(publish_data.toJSON(indent=4))
                fpo.write("\n")
            return
        self.__publish_metric(publish_data)

    def __publish_metric(self, publish_data):
        producer, topic = self.get_producer()
        producer.produce(topic, value=publish_data.toJSON(separators=(',', ':')))

    def __add_producer_auth_config(self):
        producer_config = {}
        if hasattr(self._collector_configuration, 'sink'):
            if hasattr(self._collector_configuration.sink, 'properties') and hasattr(
                    self._collector_configuration.sink.properties, 'auth') and hasattr(
                    self._collector_configuration.sink.properties.auth, 'type'):
                auth_type = self._collector_configuration.sink.properties.auth.type
                if auth_type == 'PLAIN' or auth_type == 'SCRAM-SHA-512':
                    producer_config['security.protocol'] = "SASL_PLAINTEXT"
                    producer_config['sasl.mechanism'] = 'PLAIN' if auth_type == 'PLAIN' else 'SCRAM-SHA-512'
                    producer_config['sasl.username'] = base64.b64decode(
                        self._collector_configuration.sink.properties.auth.username).decode('utf-8')
                    producer_config['sasl.password'] = base64.b64decode(
                        self._collector_configuration.sink.properties.auth.password).decode('utf-8')
                elif auth_type == 'SSL' or auth_type == 'TLS':
                    producer_config['security.protocol'] = 'SSL'
                    producer_config['ssl.truststore.type'] = 'PEM'
                    producer_config['ssl.truststore.certificates'] = base64.b64decode(
                        self._collector_configuration.sink.properties.ssl.cert).decode('utf-8')
                    producer_config['ssl.keystore.key'] = base64.b64decode(
                        self._collector_configuration.sink.properties.ssl.cert).decode('utf-8')
                    producer_config['ssl.keystore.type'] = 'PEM'
                    producer_config['ssl.keystore.certificate.chain'] = base64.b64decode(
                        self._collector_configuration.sink.properties.auth.cert).decode('utf-8')
                elif auth_type == 'OAUTHBEARER':
                    token_endpoint = self._collector_configuration.sink.properties.auth.token_url
                    client_id = self._collector_configuration.sink.properties.auth.client_id
                    client_secret = self._collector_configuration.sink.properties.auth.client_secret
                    oauth_https = self._collector_configuration.sink.properties.auth.oauth_https
                    oauth_cert_data = self._collector_configuration.sink.properties.auth.oauth_cert
                    producer_config['security.protocol'] = 'SASL_SSL'
                    producer_config['sasl.mechanism'] = 'OAUTHBEARER'
                    producer_config['oauthbearer.config'] = 'metadata_oauthbearer_config'
                    producer_config['sasl.login.callback.class'] = 'oauthbearer_sasl_callback'
                    if oauth_https:
                        producer_config['oauthbearer.https.only'] = 'true'
                        if oauth_cert_data:
                            # Set OAuth certificate configuration
                            oauth_cert = base64.b64decode(oauth_cert_data).decode('utf-8')
                            # Write the OAuth certificate data to a temporary file
                            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                                temp_file.write(oauth_cert.encode('utf-8'))
                                producer_config['ssl.ca.location'] = temp_file.name
                    # Set OAuth client credentials
                    oauth_config = f"token_endpoint={token_endpoint},client_id={client_id},client_secret={client_secret}"
                    producer_config['oauthbearer.config'] = oauth_config
                elif auth_type == 'GSSAPI' or auth_type == 'KERBEROS':
                    principal_base64 = self._collector_configuration.sink.properties.auth.principal
                    keytab_base64 = self._collector_configuration.sink.properties.auth.keytab
                    service_name = self._collector_configuration.sink.properties.auth.service_name
                    kdc_server = self._collector_configuration.sink.properties.auth.kdc
                    realm_name = self._collector_configuration.sink.properties.auth.realm
                    producer_config['security.protocol'] = 'SASL_SSL'
                    producer_config['sasl.mechanism'] = 'GSSAPI'
                    producer_config['sasl.kerberos.service.name'] = service_name

                    principal = base64.b64decode(principal_base64).decode('utf-8')
                    keytab_data = base64.b64decode(keytab_base64)

                    # Write the keytab data to a temporary file
                    with tempfile.NamedTemporaryFile(delete=False) as keytab_file:
                        keytab_file.write(keytab_data)
                        keytab_path = keytab_file.name

                    # Generate a temporary krb5.conf file
                    krb5_conf = f'''[libdefaults]
                        default_realm = {realm_name}
                        kdc_timesync = 1
                        ccache_type = 4
                        forwardable = true
                        proxiable = true
                        
                        [realms]
                        {realm_name} = {{
                            kdc = {kdc_server}
                        }}
                        
                        [domain_realm]
                        .{realm_name} = {realm_name}
                        {realm_name} = {realm_name}'''

                    # Write the krb5.conf data to a temporary file
                    with tempfile.NamedTemporaryFile(delete=False) as krb5_conf_file:
                        krb5_conf_file.write(krb5_conf.encode('utf-8'))
                        krb5_conf_path = krb5_conf_file.name

                    # Set the Kerberos environment variables
                    os.environ['KRB5_CLIENT_KTNAME'] = keytab_path
                    os.environ['KRB5_KTNAME'] = keytab_path
                    os.environ['KRB5_CONFIG'] = krb5_conf_path
                    os.environ['KRB5CCNAME'] = f'FILE:/tmp/krb5cc_{os.getuid()}'
                    os.environ['KRB5_KTYPES'] = 'FILE'

                    # Set the Kerberos configurations
                    producer_config['sasl.kerberos.principal'] = principal
                    producer_config['sasl.kerberos.keytab'] = keytab_path
            if hasattr(self._collector_configuration.sink, 'properties') and hasattr(
                    self._collector_configuration.sink.properties, 'ssl'):
                ssl_enabled = self._collector_configuration.sink.properties.ssl.enabled
                if ssl_enabled:
                    producer_config['ssl.truststore.type'] = 'PEM'
                    producer_config['ssl.truststore.certificates'] = base64.b64decode(
                        self._collector_configuration.sink.properties.ssl.cert).decode('utf-8')
        return producer_config

    def get_remote_sink_config(self):
        bootstrap_server = None
        # TCO-9241 remote Collector always writes to Edge kafka
        if hasattr(self._collector_configuration.sink, 'properties') and hasattr(
                self._collector_configuration.sink.properties, 'bootstrap_servers'):
            bootstrap_server = self._collector_configuration.sink.properties.bootstrap_servers
            if bootstrap_server == "internal-kafka-bootstrap:9092" or \
                    bootstrap_server == "kafka-edge:32092" or \
                    bootstrap_server == "edge-kafka-bootstrap:9093":
                return get_default_edge_kafka_conf()
            else:
                kafka_config = {
                    "bootstrap.servers": bootstrap_server,
                    "batch.size": 32768,  # Adjust the batch size as per your requirements
                    "linger.ms": 10
                }
                kafka_config.update(self.__add_producer_auth_config())
                return kafka_config
        else:
            return get_default_edge_kafka_conf()

    def get_destination_topic_name(self):
        topic = None
        if hasattr(self._collector_configuration.sink, 'topic'):
            topic = self._collector_configuration.sink.topic
        if topic is None or topic == '':
            topic = os.getenv("TOPIC_NAME", 'vsa_metrics_raw')
        return topic

    def flush_producer(self):
        if self.producer:  # Make sure the producer object is defined
            self.producer.flush()

    def collect_from_file(self):
        self._logger.info("inside collect_from_file function")
        self._collected_data = None
        if self.input_file and self.input_file !='':
            f = open(self.input_file)
            data = json.load(f)
            for row in data:
                self._collected_data = row
                self._transformed_data = self.transform()
                self.publish(self._transformed_data)

