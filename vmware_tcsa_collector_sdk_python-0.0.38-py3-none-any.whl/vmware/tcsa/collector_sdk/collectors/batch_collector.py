import time
from logging import Logger
import abc
from apscheduler.schedulers.background import BackgroundScheduler

from vmware.tcsa.collector_sdk.collectors.base import BaseCollector
from vmware.tcsa.collector_sdk.models.base import TCOBase


class BatchCollector(BaseCollector):
    def __init__(self, logger: Logger, collector_configuration) -> None:
        super().__init__(logger, collector_configuration)
        self._collector_configuration = collector_configuration
        self.input_file = collector_configuration.collector_input_file

    def invoke(self, command: chr) -> TCOBase:
        if self.input_file and self.input_file != '':
            self.collect_from_file()
        else:
            self._collected_data = self.collect()
            self._transformed_data = self.transform()
            self.publish(self._transformed_data)

    @abc.abstractmethod
    def collect(self):
        pass

    @abc.abstractmethod
    def transform(self) -> TCOBase:
        pass
