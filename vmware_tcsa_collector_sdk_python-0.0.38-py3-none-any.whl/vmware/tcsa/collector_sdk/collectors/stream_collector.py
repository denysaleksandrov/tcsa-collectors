import abc
from vmware.tcsa.collector_sdk.collectors.base import BaseCollector
from vmware.tcsa.collector_sdk.models.base import TCOBase


class StreamCollector(BaseCollector):
    def __init__(self, logger, config) -> None:
        super().__init__(logger, config)
        self._config = config
        self.input_file = config.collector_input_file

    @abc.abstractmethod
    def collect(self):
        pass

    @abc.abstractmethod
    def transform(self) -> TCOBase:
        pass

    def invoke(self, command: chr):
        if self.input_file and self.input_file != '':
            self.collect_from_file()
        else:
            self._collected_data = self.collect()
            self._transformed_data = self.transform()
            self.publish(self._transformed_data)
