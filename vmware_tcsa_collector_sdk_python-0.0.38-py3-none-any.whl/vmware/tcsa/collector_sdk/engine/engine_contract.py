from typing import Optional, List

from vmware.tcsa.collector_sdk.models.base import TCOBase
from vmware.tcsa.collector_sdk.models.models import PackageMetaData


class IPluginRegistry(type):
    plugin_registries: List[type] = list()

    def __init__(cls, name, bases, attrs):
        super().__init__(cls)
        if name != 'PluginCore':
            IPluginRegistry.plugin_registries.append(cls)


class PluginCore(object, metaclass=IPluginRegistry):
    """
    Plugin core class
    """
    meta: Optional[PackageMetaData]

    def __init__(self, logger) -> None:
        """
        Entry init block for plugins
        :param logger: logger that plugins can make use of
        """
        self._logger = logger

    def invoke(self, **args) -> TCOBase:
        """
        Starts main plugin flow
        :param args: possible arguments for the plugin
        :return: a TCOBase for the publishing into kafka
        """
        pass
