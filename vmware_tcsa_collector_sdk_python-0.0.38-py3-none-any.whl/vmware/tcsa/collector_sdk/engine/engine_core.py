import os.path
from logging import Logger

from vmware.tcsa.collector_sdk.usecase import PluginUseCase
from vmware.tcsa.collector_sdk.util import LogUtil
from vmware.tcsa.collector_sdk.util.helpers import APP_CONFIG_DIR
from vmware.tcsa.collector_sdk.stats import app

class PluginEngine:
    _logger: Logger

    def __init__(self, **args) -> None:
        self.is_test = args['options'].get('test', False)
        self.log_file = args['options'].get('logfile')
        self.input_file = args['options'].get('input')
        self.current_path = args['options'].get('current_path')
        self._logger = LogUtil.create(args['options']['log_level'], self.log_file, self.is_test, self.current_path)
        self.use_case = PluginUseCase(args['options'])
        if self.is_test:
            self.config_file = os.path.join(self.current_path, args['options'].get('config'))
            self.config_schema_file = os.path.join(self.current_path, args['options'].get('config_schema'))
        else:
            self.config_file = os.path.join(APP_CONFIG_DIR, args['options'].get('config'))
            self.config_schema_file = os.path.join(APP_CONFIG_DIR, args['options'].get('config_schema'))
        self.output_file = args['options'].get('output_file')

    def start(self) -> None:
        self.__reload_plugins(self.is_test, self.config_file, self.config_schema_file)
        self.__invoke_on_plugins('Q')

    def __reload_plugins(self, is_test: bool, config_file, config_schema_file) -> None:
        """Reset the list of all plugins and initiate the walk over the main
        provided plugin package to load all available plugins
        """
        self.use_case.discover_plugins(True, is_test, config_file, config_schema_file, self.current_path)

    def __invoke_on_plugins(self, command: chr):
        """Apply all of the plugins on the argument supplied to this function
        """
        for module in self.use_case.modules:
            collector_config = self.use_case.module_config.get(module.__module__)
            setattr(collector_config, "is_test_run", self.is_test)
            setattr(collector_config, "collector_input_file", self.input_file)
            setattr(collector_config, "collector_output_file", self.output_file)
            plugin = self.use_case.register_plugin(module, self._logger, collector_config)
            delegate = self.use_case.hook_plugin(plugin)
            device = delegate(command=command)
            self._logger.info(f'Loaded device: {device}')
