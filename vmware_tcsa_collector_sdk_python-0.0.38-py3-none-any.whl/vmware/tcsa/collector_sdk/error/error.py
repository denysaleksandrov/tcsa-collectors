class BaseError(Exception):
    """Base class for all Collector errors."""


class RuntimeError(BaseError):
    """An error related to a Runner object (e.g. cannot find a runner to run)."""


class RuntimeValueProviderError(RuntimeError):
    """An error related to a ValueProvider object raised during runtime."""


class InputError(BaseError):
    """An error related to a side input to a parallel Do operation."""


class TransformError(BaseError):
    """An error related to a PTransform object."""


class UnsupportedOperation(Exception):
    """An error related to a PTransform object."""


class ConfigurationExeception(BaseError):
    """An error related to a Configuration input."""
